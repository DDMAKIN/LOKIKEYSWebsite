# Ads-Ready Security & Transparency Kit

Drop these files into the root of your website's GitHub repo (the one Figma Make created, or your own).

## What's inside

| File | What it does |
|---|---|
| `ADS-READINESS-CHECKLIST.md` | Full security + transparency checklist for Google Ads and Meta Ads. Tick boxes as you go. |
| `SECURITY.md` | Security policy — GitHub shows it in the repo's **Security** tab. |
| `public/robots.txt` | Lets Google AdsBot, Googlebot and Facebook's crawler read the site. |
| `public/privacy-policy.html` | Privacy Policy page (India DPDP Act-aware). Replace every `[PLACEHOLDER]`. |
| `vercel.json` | HTTPS + security headers when hosted on Vercel. |
| `public/_headers` | Same security headers for Netlify / Cloudflare Pages. |
| `.gitignore` | Stops `.env` files and keys from being committed. |
| `.github/workflows/secret-scan.yml` | Scans every push for leaked API keys (Gitleaks). |
| `.github/dependabot.yml` | Weekly pull requests for vulnerable npm packages. |

## How to add it to GitHub (no coding)

1. Open your repo on github.com.
2. Click **Add file → Upload files**.
3. Drag in **everything inside this folder** (keep the `public` and `.github` folders as they are).
   - Tip: hidden folders like `.github` may not show in Finder/Explorer. Press `Cmd+Shift+.` (Mac) or turn on "Hidden items" (Windows) first.
4. Commit message: `Add ads-ready security & transparency kit` → **Commit changes**.

If your repo already has a `.gitignore`, `robots.txt` or `vercel.json`, merge the contents instead of overwriting.

## After uploading

- [ ] Replace all `[PLACEHOLDER]` text in `privacy-policy.html` and `SECURITY.md`
- [ ] Replace `YOUR-DOMAIN.com` in `robots.txt`
- [ ] Add a **Privacy Policy** link to the site footer pointing to `/privacy-policy.html`
- [ ] Repo **Settings → Code security**: turn on *Secret scanning* and *Dependabot alerts*
- [ ] Work through `ADS-READINESS-CHECKLIST.md`

## Notes

- **Figma Make pushes overwrite the repo.** Figma Make's GitHub push is one-way, so files added on GitHub can be wiped on the next push. Either stop pushing from Make once you've added this kit, or ask Make to add these same files inside the project.
- **Gitleaks** is free for personal GitHub accounts. A GitHub *organization* repo needs a free licence key from gitleaks.io (add it as the `GITLEAKS_LICENSE` secret), or delete the workflow and rely on GitHub's built-in secret scanning.
- **GitHub Pages** can't set custom headers. Host on Vercel/Netlify for the header files to work.
- The privacy policy is a starting template, not legal advice. Have it reviewed if you collect payments or sensitive data.
